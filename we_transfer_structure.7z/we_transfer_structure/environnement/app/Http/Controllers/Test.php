<?php
/*****************************************************
* 
* Author :
* Version :
* 
* Description :
* 
*/



// definissons une variable 
$title = "SuperTitre";
$content = ["pomme","poire","carotte","tomate"];

require(ROOT_DIR.'/resources/views/template/main.html.php');
// le but est maintenant de l'afficher dans le HTML

