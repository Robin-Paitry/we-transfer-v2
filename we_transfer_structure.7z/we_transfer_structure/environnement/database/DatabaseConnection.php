<?php
/*****************************************************
* 
* Author :
* Version :
* 
* Description : Interface de connexion à la base de données
* 
*/


