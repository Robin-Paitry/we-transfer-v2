<?php
/*****************************************************
* 
* Author :
* Version :
* 
* Description :
* 
*/

// # $_SERVER['DOCUMENT_ROOT'];
// Retourne le chemin de base du site 
// Donne : C:/Users/user/htdocs

define('ROOT_DIR', dirname(__FILE__)); 
// # dirname(__FILE__);
// Retourne le chemin complet ( répertoire ) 
// Donne : C:\Users\user\htdocs\we_transfer_structure\form

define('ROOT_URL', substr($_SERVER['PHP_SELF'], 0, - (strlen($_SERVER['SCRIPT_FILENAME']) - strlen(ROOT_DIR))));
// Retourne l'url depuis le /
// Donne : /we_transfer_structure/form