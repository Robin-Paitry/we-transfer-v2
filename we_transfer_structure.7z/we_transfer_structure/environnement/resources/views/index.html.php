<div class="container">
    <div class="row">
        <div class="col-12">    
            <?php
            foreach ($content as $key => $value) {
            ?>

            Ceci est une belle : <?= $value ?> <br>

            <?php
            }
            ?>

        </div>
    </div>
</div>