<?php
/*****************************************************
* 
* Author :
* Version :
* 
* Description :
* 
*/




include('head.html.php');

include(ROOT_DIR . '/resources/views/index.html.php');

include('footer.html.php');


