<?php
/*****************************************************
* 
* Author :
* Version :
* 
* Description :
* 
*/

define('ROOT_DIR', dirname(__FILE__)); 
define('ROOT_URL', substr($_SERVER['PHP_SELF'], 0, - (strlen($_SERVER['SCRIPT_FILENAME']) - strlen(ROOT_DIR))));

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "wetransfer";

