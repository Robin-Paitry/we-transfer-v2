-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  lun. 01 avr. 2019 à 01:57
-- Version du serveur :  10.1.37-MariaDB
-- Version de PHP :  7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `pokemon`
--

-- --------------------------------------------------------

--
-- Structure de la table `dresseur`
--

CREATE TABLE `dresseur` (
  `id` int(11) NOT NULL,
  `nom_dresseur` varchar(20) NOT NULL,
  `team_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `dresseur`
--

INSERT INTO `dresseur` (`id`, `nom_dresseur`, `team_id`) VALUES
(1, 'Lambda', 1),
(2, 'Jessie', 1),
(3, 'Giovanni', 1),
(4, 'Ariane', 1),
(5, 'Amos', 1),
(6, 'Sarah', 2),
(7, 'Matthieu', 2),
(8, 'Arthur', 2),
(9, 'Hélio', 4),
(10, 'Mars', 4),
(11, 'Jupiter', 4);

-- --------------------------------------------------------

--
-- Structure de la table `pokemon`
--

CREATE TABLE `pokemon` (
  `id` int(11) NOT NULL,
  `nom_pokemon` varchar(20) NOT NULL,
  `image_pokemon` varchar(20) NOT NULL,
  `type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `pokemon`
--

INSERT INTO `pokemon` (`id`, `nom_pokemon`, `image_pokemon`, `type_id`) VALUES
(1, 'Démolosse', 'demolosse.png', 3),
(2, 'Kangourex', 'kangourex.png', 1),
(3, 'Grotadmorv', 'grotadmorv.png', 8),
(4, 'Nosferapti', 'nosferapti.png', 8),
(5, 'Rattatac', 'rattatac.png', 1),
(6, 'Nostenfer', 'nostenfer.png', 13),
(7, 'Carvanha', 'carvanha.png', 4),
(8, 'Sharpedo', 'sharpedo.png', 4),
(9, 'Cornèbre', 'cornebre.png', 13),
(10, 'Archéomire', 'archeomire.png', 12),
(11, 'Chaffreux', 'chaffreux.png', 1),
(12, 'Moufflair', 'moufflair.png', 8);

-- --------------------------------------------------------

--
-- Structure de la table `possede`
--

CREATE TABLE `possede` (
  `id` int(11) NOT NULL,
  `dresseur_id` int(11) NOT NULL,
  `pokemon_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `possede`
--

INSERT INTO `possede` (`id`, `dresseur_id`, `pokemon_id`) VALUES
(1, 5, 1),
(2, 3, 2),
(3, 4, 3),
(4, 5, 4),
(5, 1, 5),
(6, 6, 8),
(7, 7, 7),
(8, 8, 6),
(9, 11, 12),
(10, 10, 11),
(11, 10, 10),
(12, 9, 9);

-- --------------------------------------------------------

--
-- Structure de la table `team`
--

CREATE TABLE `team` (
  `id` int(11) NOT NULL,
  `team_value` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `team`
--

INSERT INTO `team` (`id`, `team_value`) VALUES
(1, 'Rocket'),
(2, 'Aqua'),
(3, 'Magma'),
(4, 'Galaxie'),
(5, 'Plasma');

-- --------------------------------------------------------

--
-- Structure de la table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `type_value` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `type`
--

INSERT INTO `type` (`id`, `type_value`) VALUES
(1, 'Normal'),
(2, 'Plante'),
(3, 'Feu'),
(4, 'Eau'),
(5, 'Insecte'),
(6, 'Combat'),
(7, 'Roche'),
(8, 'Poison'),
(9, 'Spectre'),
(10, 'Dragon'),
(11, 'Electrik'),
(12, 'Psy'),
(13, 'Vol');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `dresseur`
--
ALTER TABLE `dresseur`
  ADD PRIMARY KEY (`id`),
  ADD KEY `team_id` (`team_id`);

--
-- Index pour la table `pokemon`
--
ALTER TABLE `pokemon`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pokemon_ibfk_1` (`type_id`);

--
-- Index pour la table `possede`
--
ALTER TABLE `possede`
  ADD PRIMARY KEY (`id`),
  ADD KEY `possede_ibfk_1` (`dresseur_id`),
  ADD KEY `possede_ibfk_2` (`pokemon_id`);

--
-- Index pour la table `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `dresseur`
--
ALTER TABLE `dresseur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `pokemon`
--
ALTER TABLE `pokemon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `possede`
--
ALTER TABLE `possede`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `team`
--
ALTER TABLE `team`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `dresseur`
--
ALTER TABLE `dresseur`
  ADD CONSTRAINT `dresseur_ibfk_1` FOREIGN KEY (`team_id`) REFERENCES `team` (`id`);

--
-- Contraintes pour la table `pokemon`
--
ALTER TABLE `pokemon`
  ADD CONSTRAINT `pokemon_ibfk_1` FOREIGN KEY (`type_id`) REFERENCES `type` (`id`);

--
-- Contraintes pour la table `possede`
--
ALTER TABLE `possede`
  ADD CONSTRAINT `possede_ibfk_1` FOREIGN KEY (`dresseur_id`) REFERENCES `dresseur` (`id`),
  ADD CONSTRAINT `possede_ibfk_2` FOREIGN KEY (`pokemon_id`) REFERENCES `pokemon` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
