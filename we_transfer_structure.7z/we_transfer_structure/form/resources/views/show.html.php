<div class="alert alert-primary" role="alert">

<?= $mail_exp ?>

<?= $mail_dest?>

<?= $message ?>

</div>